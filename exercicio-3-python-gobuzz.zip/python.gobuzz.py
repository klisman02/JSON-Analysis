import json

# Dados fornecidos
dados_comentarios = [
    {
        "id": 1,
        "nome": "Alice",
        "comentario": "Ótimo trabalho!",
        "data_hora": "2023-11-01 10:30:45",
        "interacoes": 10
    },
    {
        "id": 2,
        "nome": "Bob",
        "comentario": "Isso é uma ofensa!",
        "data_hora": "2023-11-02 12:15:20",
        "interacoes": 5
    },
    {
        "id": 3,
        "nome": "Charlie",
        "comentario": "Insulto gratuito.",
        "data_hora": "2023-11-03 14:05:10",
        "interacoes": 12
    },
    {
        "id": 4,
        "nome": "David",
        "comentario": "Adorei o conteúdo.",
        "data_hora": "2023-11-04 16:40:55",
        "interacoes": 15
    },
    {
        "id": 5,
        "nome": "Eve",
        "comentario": "Comentário agressivo.",
        "data_hora": "2023-11-05 09:20:30",
        "interacoes": 8
    },
    {
        "id": 6,
        "nome": "Frank",
        "comentario": "Nada a acrescentar.",
        "data_hora": "2023-11-06 11:55:25",
        "interacoes": 3
    },
    {
        "id": 7,
        "nome": "Grace",
        "comentario": "Ofensa direta.",
        "data_hora": "2023-11-07 13:10:15",
        "interacoes": 6
    },
    {
        "id": 8,
        "nome": "Hank",
        "comentario": "Comentário construtivo.",
        "data_hora": "2023-11-08 15:45:40",
        "interacoes": 10
    },
    {
        "id": 9,
        "nome": "Ivy",
        "comentario": "Muito útil, obrigado!",
        "data_hora": "2023-11-09 17:30:50",
        "interacoes": 18
    },
    {
        "id": 10,
        "nome": "Jack",
        "comentario": "Que absurdo!",
        "data_hora": "2023-11-10 19:25:35",
        "interacoes": 7
    },
    {
        "id": 11,
        "nome": "Alice",
        "comentario": "Excelente!",
        "data_hora": "2023-11-11 21:15:45",
        "interacoes": 14
    },
    {
        "id": 12,
        "nome": "Bob",
        "comentario": "Não concordo.",
        "data_hora": "2023-11-12 08:05:55",
        "interacoes": 9
    },
    {
        "id": 13,
        "nome": "Charlie",
        "comentario": "Gostei do conteúdo.",
        "data_hora": "2023-11-13 10:30:45",
        "interacoes": 13
    },
    {
        "id": 14,
        "nome": "David",
        "comentario": "Isso é incrível!",
        "data_hora": "2023-11-14 12:20:35",
        "interacoes": 20
    },
    {
        "id": 15,
        "nome": "Eve",
        "comentario": "Acho que poderia melhorar.",
        "data_hora": "2023-11-15 14:15:25",
        "interacoes": 6
    },
    {
        "id": 16,
        "nome": "Frank",
        "comentario": "Sem comentários.",
        "data_hora": "2023-11-16 16:10:15",
        "interacoes": 2
    },
    {
        "id": 17,
        "nome": "Grace",
        "comentario": "Gosto disso!",
        "data_hora": "2023-11-17 18:05:05",
        "interacoes": 11
    },
    {
        "id": 18,
        "nome": "Hank",
        "comentario": "Bom trabalho.",
        "data_hora": "2023-11-18 20:00:00",
        "interacoes": 8
    },
    {
        "id": 19,
        "nome": "Ivy",
        "comentario": "Parabéns!",
        "data_hora": "2023-11-19 21:55:55",
        "interacoes": 17
    },
    {
        "id": 20,
        "nome": "Jack",
        "comentario": "Interessante.",
        "data_hora": "2023-11-20 23:50:50",
        "interacoes": 5
    }
]

# Identificar o usuário que fez o maior número de comentários
usuario_max_comentarios = max(dados_comentarios, key=lambda x: dados_comentarios.count(x["nome"]))
print(f"Usuário com mais comentários: {usuario_max_comentarios['nome']}")

# Identificar o usuário com a maior soma de interações
usuario_max_interacoes = max(dados_comentarios, key=lambda x: x["interacoes"])
print(f"Usuário com mais interações: {usuario_max_interacoes['nome']}")

# Trazer todos os dados do comentário com a maior interação
comentario_max_interacoes = max(dados_comentarios, key=lambda x: x["interacoes"])
print(f"Dados do comentário com mais interações: {json.dumps(comentario_max_interacoes, indent=4)}")


'''
Resultados do código

Usuário com mais comentários: Alice
Usuário com mais interações: David        
Dados do comentário com mais interações: {
    "id": 14,
    "nome": "David",
    "comentario": "Isso \u00e9 incr\u00edvel!",
    "data_hora": "2023-11-14 12:20:35",
    "interacoes": 20
}

'''